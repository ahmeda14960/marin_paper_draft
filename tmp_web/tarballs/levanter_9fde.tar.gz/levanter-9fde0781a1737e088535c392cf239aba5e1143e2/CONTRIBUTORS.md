# Contributors

The following individuals have authored commits to this project (listed by commit count as of September 2025):

- 1141 David Hall <dlwh@stanford.edu>
- 124 Ahmed Ahmed <ahmedah@stanford.edu>
- 46 Yifan Mai <yifan@cs.stanford.edu>
- 33 Ivan Zhou <ivan.zhouyq@gmail.com>
- 29 William Held <Wbh230@nyu.edu>
- 21 Jason Wang <blahblahj.wsy@gmail.com>
- 16 Kaiyue Wen <kaiyue@sc.stanford.edu>
- 11 Gary Miguel <garymm@garymm.org>
- 11 Kamyar Salahi <kam.salahi@berkeley.edu>
- 11 Russell Power <russell.power@gmail.com>
- 8 whenwen <kaiyuewen3@gmail.com>
- 6 William Arnold <will748@gmail.com>
- 5 Nikil Ravi <nravi@stanford.edu>
- 5 Virginia Adams <78445382+vadam5@users.noreply.github.com>
- 4 Javier de la Rosa <versae@gmail.com>
- 4 Nikil Ravi <55033516+nikil-ravi@users.noreply.github.com>
- 3 Suhas Kotha <38450656+kothasuhas@users.noreply.github.com>
- 2 Abhinav Garg <abhinavg@stanford.edu>
- 2 Emmanuel Ferdman <emmanuelferdman@gmail.com>
- 2 Jennifer Zhou <jennifer@jezh.me>
- 2 Marcel Rød <marcelroed@gmail.com>
- 2 Mike Lay <mike@mkly.io>
- 1 Anh Tong <anhth@unist.ac.kr>
- 1 Calvin Xu <calvinxu806@gmail.com>
- 1 Joel Niklaus <j.niklaus.95@gmail.com>
- 1 Neel Gupta <neelgupta04@outlook.com>
- 1 Oleg <142805497+devactivity-team@users.noreply.github.com>
- 1 Patrick Kidger <33688385+patrick-kidger@users.noreply.github.com>
- 1 Rohan Taori <rtaori13@gmail.com>
- 1 Sunil Pinnamaneni <2009181+raisin@users.noreply.github.com>
- 1 Will <212922539+cats-marin@users.noreply.github.com>
- 1 jyc <jyc@eqv.io>
