# The Levanter Authors

For purposes of copyright, the Levanter Authors currently include:
(Contributors are also listed in CONTRIBUTORS.md.)

- The Board of Trustees of the Leland Stanford Junior University
- William Held
- Russell Power
- Gary Miguel
- Kamyar Salahi
