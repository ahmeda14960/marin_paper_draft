python infra/push_docker.py --docker_file docker/tpu/Dockerfile.cluster --image levanter-cluster --tag latest $*
